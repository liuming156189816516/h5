// Copyright 2012-present Oliver Eilhard. All rights reserved.
// Use of this source code is governed by a MIT-license.
// See http://olivere.mit-license.org/license.txt for details.

package elastic

import (
	"testing"
	"time"
)

func TestBulkCreateRequestSerialization(t *testing.T) {
	tests := []struct {
		Request  BulkableRequest
		Expected []string
	}{
		// #0
		{
			Request: NewBulkCreateRequest().Index("index1").Id("1").
				Doc(tweet{User: "olivere", Created: time.Date(2014, 1, 18, 23, 59, 58, 0, time.UTC)}),
			Expected: []string{
				`{"create":{"_index":"index1","_id":"1"}}`,
				`{"user":"olivere","message":"","retweets":0,"created":"2014-01-18T23:59:58Z"}`,
			},
		},
		// #1
		{
			Request: NewBulkCreateRequest().Index("index1").Id("1").
				Doc(tweet{User: "olivere", Created: time.Date(2014, 1, 18, 23, 59, 58, 0, time.UTC)}),
			Expected: []string{
				`{"create":{"_index":"index1","_id":"1"}}`,
				`{"user":"olivere","message":"","retweets":0,"created":"2014-01-18T23:59:58Z"}`,
			},
		},
		// #2
		{
			Request: NewBulkCreateRequest().Index("index1").Id("1").RetryOnConflict(42).
				Doc(tweet{User: "olivere", Created: time.Date(2014, 1, 18, 23, 59, 58, 0, time.UTC)}),
			Expected: []string{
				`{"create":{"_index":"index1","_id":"1","retry_on_conflict":42}}`,
				`{"user":"olivere","message":"","retweets":0,"created":"2014-01-18T23:59:58Z"}`,
			},
		},
		// #3
		{
			Request: NewBulkCreateRequest().Index("index1").Id("1").Pipeline("my_pipeline").
				Doc(tweet{User: "olivere", Created: time.Date(2014, 1, 18, 23, 59, 58, 0, time.UTC)}),
			Expected: []string{
				`{"create":{"_index":"index1","_id":"1","pipeline":"my_pipeline"}}`,
				`{"user":"olivere","message":"","retweets":0,"created":"2014-01-18T23:59:58Z"}`,
			},
		},
		// #4
		{
			Request: NewBulkCreateRequest().Index("index1").Id("1").
				Routing("123").
				Doc(tweet{User: "olivere", Created: time.Date(2014, 1, 18, 23, 59, 58, 0, time.UTC)}),
			Expected: []string{
				`{"create":{"_index":"index1","_id":"1","routing":"123"}}`,
				`{"user":"olivere","message":"","retweets":0,"created":"2014-01-18T23:59:58Z"}`,
			},
		},
		// #5
		{
			Request: NewBulkCreateRequest().Index("index1").Type("doc").Id("1").
				Version(0).
				VersionType("external").
				Doc(tweet{User: "olivere", Created: time.Date(2014, 1, 18, 23, 59, 58, 0, time.UTC)}),
			Expected: []string{
				`{"create":{"_index":"index1","_id":"1","_type":"doc","version":0,"version_type":"external"}}`,
				`{"user":"olivere","message":"","retweets":0,"created":"2014-01-18T23:59:58Z"}`,
			},
		},
	}

	for i, test := range tests {
		lines, err := test.Request.Source()
		if err != nil {
			t.Fatalf("case #%d: expected no error, got: %v", i, err)
		}
		if lines == nil {
			t.Fatalf("case #%d: expected lines, got nil", i)
		}
		if len(lines) != len(test.Expected) {
			t.Fatalf("case #%d: expected %d lines, got %d", i, len(test.Expected), len(lines))
		}
		for j, line := range lines {
			if line != test.Expected[j] {
				t.Errorf("case #%d: expected line #%d to be %s, got: %s", i, j, test.Expected[j], line)
			}
		}
	}
}

var bulkCreateRequestSerializationResult string

func BenchmarkBulkCreateRequestSerialization(b *testing.B) {
	b.Run("stdlib", func(b *testing.B) {
		r := NewBulkCreateRequest().Index(testIndexName).Id("1").
			Doc(tweet{User: "olivere", Created: time.Date(2014, 1, 18, 23, 59, 58, 0, time.UTC)})
		benchmarkBulkCreateRequestSerialization(b, r.UseEasyJSON(false))
	})
	b.Run("easyjson", func(b *testing.B) {
		r := NewBulkCreateRequest().Index(testIndexName).Id("1").
			Doc(tweet{User: "olivere", Created: time.Date(2014, 1, 18, 23, 59, 58, 0, time.UTC)})
		benchmarkBulkCreateRequestSerialization(b, r.UseEasyJSON(true))
	})
}

func benchmarkBulkCreateRequestSerialization(b *testing.B, r *BulkCreateRequest) {
	var s string
	for n := 0; n < b.N; n++ {
		s = r.String()
		r.source = nil // Don't let caching spoil the benchmark
	}
	bulkCreateRequestSerializationResult = s // ensure the compiler doesn't optimize
	b.ReportAllocs()
}
